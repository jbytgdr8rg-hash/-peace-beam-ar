# Peace Beam Invaders v9 - Branch Deploy

GitHub Pages の「Deploy from a branch」専用版です。

この版には `.github/workflows` を入れていません。静的な `index.html` だけなので、Actions を使う必要がありません。

## 推奨設定

Settings → Pages → Build and deployment

- Source: Deploy from a branch
- Branch: main
- Folder: /(root)

公開URLは以下の形式です。

```text
https://<GitHubユーザー名>.github.io/<リポジトリ名>/
```
